package com.example.id_verification;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.backendless.BackendlessUser;

import java.util.List;

public class CivilianAdapter extends RecyclerView.Adapter<CivilianAdapter.ViewHolder> {

    private List<IdentityInformation> civilian;
    CivilianAdapter.ItemClicked activity;

    public  interface ItemClicked
    {
        void onItemClicked(int index);
    }

    public CivilianAdapter(Context context, List<IdentityInformation> list)
    {
        civilian = list;
        activity = (ItemClicked) context;
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {

        TextView issueDate, name,surname;

        public ViewHolder(@NonNull View itemView)
        {
            super(itemView);


            issueDate = itemView.findViewById(R.id.tvCDateofissue);
            name = itemView.findViewById(R.id.tvCNames);
            surname = itemView.findViewById(R.id.tvCSurname);


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    activity.onItemClicked(civilian.indexOf((IdentityInformation) v.getTag()));
                }
            });
        }
    }

    @NonNull
    @Override
    public CivilianAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.civilian_layout,
                parent, false);

        return new CivilianAdapter.ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull CivilianAdapter.ViewHolder holder, int position) {

        holder.itemView.setTag(civilian.get(position));

        holder.issueDate.setText(civilian.get(position).getDate_Of_Issue() + " ");
        holder.name.setText(civilian.get(position).getNames());
        holder.surname.setText(civilian.get(position).getSurname());


    }

    @Override
    public int getItemCount()
    {
        return civilian.size();
    }


}
