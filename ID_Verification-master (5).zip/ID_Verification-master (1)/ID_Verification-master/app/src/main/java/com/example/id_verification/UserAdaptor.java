package com.example.id_verification;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.backendless.BackendlessUser;

import java.util.List;

public class UserAdaptor extends RecyclerView.Adapter<UserAdaptor.ViewHolder> {

    private  List<BackendlessUser> policeOfficer;
    ItemClicked activity;

    public  interface ItemClicked
    {
        void onItemClicked(int index);
    }

    public UserAdaptor(Context context, List<BackendlessUser> list)
    {
        policeOfficer = list;
        activity = (ItemClicked) context;
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {

        TextView rank, name,surname;

        public ViewHolder(@NonNull View itemView)
        {
            super(itemView);


            rank = itemView.findViewById(R.id.rank);
            name = itemView.findViewById(R.id.name);
            surname = itemView.findViewById(R.id.Surname);


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    activity.onItemClicked(policeOfficer.indexOf((BackendlessUser) v.getTag()));
                }
            });
        }
    }

    @NonNull
    @Override
    public UserAdaptor.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_layout,
                parent, false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull UserAdaptor.ViewHolder holder, int position) {

       holder.itemView.setTag(policeOfficer.get(position));

        holder.rank.setText(policeOfficer.get(position).getProperty("OfficerRank").toString());
        holder.name.setText(policeOfficer.get(position).getProperty("Officernames").toString());
        holder.surname.setText(policeOfficer.get(position).getProperty("OfficerSurname").toString());


    }

    @Override
    public int getItemCount()
    {
        return policeOfficer.size();
    }


}
