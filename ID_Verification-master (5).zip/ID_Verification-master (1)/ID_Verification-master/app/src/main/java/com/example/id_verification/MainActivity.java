package com.example.id_verification;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.backendless.Backendless;
import com.backendless.async.callback.AsyncCallback;
import com.backendless.exceptions.BackendlessFault;
import com.backendless.persistence.DataQueryBuilder;

import java.util.List;

public class MainActivity extends AppCompatActivity
{

    private View mProgressView;
    private View mRegisterFormView;
    private TextView tvLoad;

    TextView tvRegisterHome;

    EditText etID;



    Button btnRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Home Screen");

        mRegisterFormView = findViewById(R.id.login_form);
        mProgressView = findViewById(R.id.login_progress);
        tvLoad = findViewById(R.id.tvLoad);

        tvRegisterHome = findViewById(R.id.tvRegisterHome);

        etID = findViewById(R.id.etID);



        btnRegister = findViewById(R.id.btnRegister);


        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                if(etID.getText().toString().isEmpty())
                {
                    Toast.makeText(MainActivity.this, "Please enter all fields!", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    int IdNumber = Integer.parseInt(etID.getText().toString());


                    String whereClause = "IdNumber = '"+IdNumber+"'";

                    DataQueryBuilder queryBuilder = DataQueryBuilder.create();
                    queryBuilder.setWhereClause(whereClause);
                    queryBuilder.setGroupBy("created");

                    Backendless.Persistence.of(IdentityInformation.class).find(queryBuilder, new AsyncCallback<List<IdentityInformation>>() {
                        @Override
                        public void handleResponse(List<IdentityInformation> response) {

                            Toast.makeText( MainActivity.this, "Civilian found  " + response, Toast.LENGTH_SHORT).show();
                            ApplicationClass.identityList = response;

                            Intent mainIntent = new Intent(MainActivity.this,Civilian_List.class);
                            startActivity(mainIntent);


                        }

                        @Override
                        public void handleFault(BackendlessFault fault) {

                            Toast.makeText(MainActivity.this, "Error: "+ fault.getMessage(), Toast.LENGTH_SHORT).show();

                        }
                    });




                }

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

       // getMenuInflater().inflate();
        return super.onCreateOptionsMenu(menu);
    }
}
