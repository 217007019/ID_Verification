package com.example.id_verification;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.backendless.Backendless;
import com.backendless.async.callback.AsyncCallback;
import com.backendless.exceptions.BackendlessFault;
import com.backendless.persistence.DataQueryBuilder;

import java.util.List;

public class Civilian_List extends AppCompatActivity implements CivilianAdapter.ItemClicked {

    RecyclerView rvCivilian;
    RecyclerView.LayoutManager layoutManager;
    RecyclerView.Adapter myAdapter;

    Button btnSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_civilian__list);

        rvCivilian=findViewById(R.id.rvCivilian);
        rvCivilian.setHasFixedSize(true);

        layoutManager = new LinearLayoutManager(this);
        rvCivilian.setLayoutManager(layoutManager);

        btnSave = findViewById(R.id.btnSave);


        myAdapter= new CivilianAdapter(Civilian_List.this,ApplicationClass.identityList);
        rvCivilian.setAdapter(myAdapter);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Civilian_List.this, Scan.class);
                startActivity(intent);

            }
        });

    }

    @Override
    public void onItemClicked(int index) {

    }
}