package com.example.id_verification;

import android.app.Application;

import com.backendless.Backendless;
import com.backendless.BackendlessUser;

import java.util.List;

public class ApplicationClass extends Application
{
    public static final String APPLICATION_ID = "0514E5DE-8B8B-7C5B-FF77-19AEC45EF900";
    public static final String API_KEY = "F7E50D2D-1AA6-4372-B824-58EBABADCB27";
    public static final String SERVER_URL = "https://api.backendless.com";

    public static BackendlessUser user;
    public static List<BackendlessUser> userList;
    public  static List<IdentityInformation> identityList;

    @Override
    public void onCreate()
    {

        super.onCreate();

        Backendless.setUrl( SERVER_URL );
        Backendless.initApp( getApplicationContext(),
                APPLICATION_ID,
                API_KEY );

    }




}
