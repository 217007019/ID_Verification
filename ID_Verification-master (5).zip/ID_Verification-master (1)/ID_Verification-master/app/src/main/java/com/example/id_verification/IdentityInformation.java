package com.example.id_verification;

import java.util.Date;

public class IdentityInformation {

    private  int IdNumber;
    private  String Names;
    private  String Surname;
    private Date Date_Of_Issue;

    public int getIdNumber() {
        return IdNumber;
    }

    public void setIdNumber(int idNumber) {
        IdNumber = idNumber;
    }

    public String getNames() {
        return Names;
    }

    public void setNames(String names) {
        Names = names;
    }

    public String getSurname() {
        return Surname;
    }

    public void setSurname(String surname) {
        Surname = surname;
    }

    public Date getDate_Of_Issue() {
        return Date_Of_Issue;
    }

    public void setDate_Of_Issue(Date date_Of_Issue) {
        Date_Of_Issue = date_Of_Issue;
    }
}
