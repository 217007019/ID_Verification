package com.example.id_verification;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.backendless.Backendless;
import com.backendless.BackendlessUser;
import com.backendless.async.callback.AsyncCallback;
import com.backendless.exceptions.BackendlessFault;

public class Register extends AppCompatActivity {

    private View mProgressView;
    private View mLoginFormView;
    private TextView tvLoad;

    Button btnRegisterN;
    EditText etPersonnelN,etNames,etSurname,etEmail,etPassword,etConfirmP,etLocation,etID,etStation;
    AutoCompleteTextView tieProv,tieRank,tieGender;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mLoginFormView = findViewById(R.id.login_form);
        mProgressView = findViewById(R.id.login_progress);
        tvLoad = findViewById(R.id.tvLoad);

        etPersonnelN = findViewById(R.id.etPersonnelNumber);
        etNames=findViewById(R.id.etNames);
        etSurname =findViewById(R.id.etSurname);
        etID =findViewById(R.id.etIdN);
        etLocation= findViewById(R.id.etLocation);
        etStation =findViewById(R.id.etStation);
        etEmail = findViewById(R.id.etEmail);
        etPassword= findViewById(R.id.etPasswordR);
        etConfirmP =findViewById(R.id.etConfirmP);

        tieGender = findViewById(R.id.tieGender);
        tieProv = findViewById(R.id.tieProv);
        tieRank = findViewById(R.id.tieRank);

        btnRegisterN =findViewById(R.id.btnNewOfficer);

        btnRegisterN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if(tieProv.getText().toString().isEmpty() ||tieRank.getText().toString().isEmpty()||tieGender.getText().toString().isEmpty()
                ||etNames.getText().toString().isEmpty()||etSurname.getText().toString().isEmpty()
                ||etStation.getText().toString().isEmpty()||etLocation.getText().toString().isEmpty()||etEmail.getText().toString().isEmpty()
                ||etPassword.getText().toString().isEmpty()||etConfirmP.getText().toString().isEmpty()
                        ||etPersonnelN.getText().toString().trim().isEmpty()||etID.getText().toString().trim().isEmpty())
                {
                    Toast.makeText(Register.this, "Please enter all fields!", Toast.LENGTH_SHORT).show();
                }
                else
                {

                    if(etConfirmP.getText().toString().equals(etPassword.getText().toString()) )
                    {

                        BackendlessUser User = new BackendlessUser();
                        User.setEmail(etEmail.getText().toString().trim());
                        User.setPassword(etPassword.getText().toString().trim());
                        User.setProperty("OfficerNames",etNames.getText().toString().trim());
                        User.setProperty("OfficerSurname",etSurname.getText().toString().trim());
                        User.setProperty("PersonnelNumber",Integer.parseInt(etPersonnelN.getText().toString().trim()));
                        User.setProperty("OfficerLocation",etLocation.getText().toString().trim());
                        User.setProperty("OfficerGender",tieGender.getText().toString().trim());
                        User.setProperty("OfficerRank",tieRank.getText().toString().trim());
                        User.setProperty("OfficerProvince",tieProv.getText().toString().trim());
                        User.setProperty("OfficerStation",etStation.getText().toString().trim());
                        User.setProperty("OfficerIdNumber",Integer.parseInt(etID.getText().toString().trim()));
                        User.setProperty("UserType","Police Officer");

                        tvLoad.setText("Loading...Please wait...");
                        showProgress(true);

                        Backendless.UserService.register(User, new AsyncCallback<BackendlessUser>() {
                            @Override
                            public void handleResponse(BackendlessUser response) {


                                Toast.makeText(Register.this, "User successfully registered!", Toast.LENGTH_SHORT).show();
                                Register.this.finish();
                            }



                            @Override
                            public void handleFault(BackendlessFault fault) {

                                Toast.makeText(Register.this, "Error: " + fault.getMessage(), Toast.LENGTH_SHORT).show();
                                showProgress(false);
                            }
                        });

                    }
                    else
                    {
                        Toast.makeText(Register.this, "Passwords must match!", Toast.LENGTH_SHORT).show();
                    }
                }

            }




        });

        String[] gender_list = new String[]{
                "Male",
                "Female"
        };
        String[] rank_list = new String[]{

                "National commissioner",
       " Deputy national commissioner",
        "Divisional commissioner",
       " Provincial commissioner",
       " Assistant commissioner",
                "Director",
                "Senior superintendent",
                "Superintendent",
                "General",
                "Lieutenant-general",
                "Major-general",
                "Brigadier",
                "Colonel",
                "Lieutenant-colonel",
                "Major",
                "Captain",
      " Constable",
        "Lieutenant",
       "Warrant Officer",
       " Sergeant"

        };
        String[] province_list = new String[]{
                "Limpopo",
                "Mpumalanga",
                "Free state",
                "Gauteng",
                "North west",
                "Eastern cape",
                "Western cape",
                "Kwazulu natal",
                "Northern cape"

        };

        ArrayAdapter<String> gender_adapter = new ArrayAdapter<>(
                Register.this,R.layout.dropdownmenu,
               gender_list
        );
        ArrayAdapter<String> rank_adapter = new ArrayAdapter<>(
                Register.this,R.layout.dropdownmenu,
               rank_list
        );

        ArrayAdapter<String> province_adapter = new ArrayAdapter<>(
               Register.this,R.layout.dropdownmenu,
                province_list
        );
        tieGender.setAdapter(gender_adapter);
        tieRank.setAdapter(rank_adapter);
        tieProv.setAdapter(province_adapter);



    }//end oncreate

    /**
     * Shows the progress UI and hides the login form.
     */
    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    private void showProgress(final boolean show) {
        // On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
        // for very easy animations. If available, use these APIs to fade-in
        // the progress spinner.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);

            mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
            mLoginFormView.animate().setDuration(shortAnimTime).alpha(
                    show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
                }
            });

            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mProgressView.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });

            tvLoad.setVisibility(show ? View.VISIBLE : View.GONE);
            tvLoad.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    tvLoad.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            // The ViewPropertyAnimator APIs are not available, so simply show
            // and hide the relevant UI components.
            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            tvLoad.setVisibility(show ? View.VISIBLE : View.GONE);
            mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
        }
    }





}