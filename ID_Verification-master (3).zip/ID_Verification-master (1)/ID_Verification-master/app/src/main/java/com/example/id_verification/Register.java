package com.example.id_verification;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.backendless.Backendless;
import com.backendless.BackendlessUser;
import com.backendless.async.callback.AsyncCallback;
import com.backendless.exceptions.BackendlessFault;
import com.google.android.material.textfield.TextInputEditText;

public class Register extends AppCompatActivity
{
    private View mProgressView;
    private View  mLoginFormView;
    private TextView tvLoad;


    private EditText etPersonnelN,etRNames,etRSurnames,etRID,etStation,etLocation,etEmail,etPassword,etConform;
    private Button btnRegisterR;
    private AutoCompleteTextView sRgender,sRprovince,sRposition;

    

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Register");

        mLoginFormView = findViewById(R.id.login_form);
        mProgressView = findViewById(R.id.login_progress);
        tvLoad = findViewById(R.id.tvLoad);


        etConform = findViewById(R.id.etR_ConfirmPassword);
        etPassword = findViewById(R.id.etR_Password);
        etEmail = findViewById(R.id.etR_Email);
        etLocation= findViewById(R.id.etLocation);
       etStation= findViewById(R.id.etStation);
       etRID = findViewById(R.id.etR_ID);
        etPersonnelN = findViewById(R.id.etR_PersalNumber);
      etRSurnames = findViewById(R.id.etR_Surname);
       etRNames = findViewById(R.id.etR_Name);

        sRprovince = findViewById(R.id.province);
        sRposition = findViewById(R.id.rank);
        sRgender = findViewById(R.id.gender);

        btnRegisterR = findViewById(R.id.btnR_Register);

        btnRegisterR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(etPersonnelN.getText().toString().isEmpty() ||etRNames.getText().toString().isEmpty()||etRSurnames.getText().toString().isEmpty()||etRID.getText().toString().isEmpty()||etStation.getText().toString().isEmpty()||etLocation.getText().toString().isEmpty()||etEmail.getText().toString().isEmpty()||etPassword.getText().toString().isEmpty()||etConform.getText().toString().isEmpty())
                {
                    Toast.makeText(Register.this, "Please enter all fields!", Toast.LENGTH_SHORT).show();
                }
                else
                {
                     if(etConform.getText().toString().equals(etPassword.getText().toString()) )
                     {
                         PoliceOfficer policeOfficer = new PoliceOfficer();

                         policeOfficer.setPersonnelNumber(Integer.parseInt(etPersonnelN.getText().toString().trim()));
                         policeOfficer.setNames(etRNames.getText().toString().trim());
                         policeOfficer.setSurname(etRSurnames.getText().toString().trim());
                         policeOfficer.setEmail(etEmail.getText().toString().trim());
                         policeOfficer.setGender(sRgender.getText().toString().trim());
                         policeOfficer.setPosition(sRposition.getText().toString().trim());
                         policeOfficer.setProvince(sRprovince.getText().toString().trim());
                         policeOfficer.setStation(etStation.getText().toString().trim());
                         policeOfficer.setPassword(etPassword.getText().toString().trim());
                         policeOfficer.setIdNumber(Integer.parseInt(etRID.getText().toString().trim()));

                         tvLoad.setText("Loading...Please wait...");
                         showProgress(true);

                         Backendless.Data.of(PoliceOfficer.class).save(policeOfficer, new AsyncCallback<PoliceOfficer>() {
                             @Override
                             public void handleResponse(PoliceOfficer response) {

                                 Toast.makeText(Register.this, "New police officer successfully saved1" , Toast.LENGTH_SHORT).show();
                                 Register.this.finish();

                             }

                             @Override
                             public void handleFault(BackendlessFault fault) {

                                 Toast.makeText(Register.this, "Error: " + fault, Toast.LENGTH_SHORT).show();
                                 showProgress(false);

                             }
                         });


                     }
                     else
                     {
                         Toast.makeText(Register.this, "Passwords must match!", Toast.LENGTH_SHORT).show();
                     }
                }

            }
        });

        String[] gender = new String[]{
                "Male",
                "Female"
        };
        String[] province = new String[]{
                "Limpopo", "Free State",
                "Gauteng", "Mpumalanga",
                "North West", "Eastern Cape",
                "Western Cape", "Northern Cape",
                "Kwazulu Natal"
        };

        String[] rank= new String[]{

        };

        ArrayAdapter<String> gender_adapter = new ArrayAdapter<>(
                Register.this,R.layout.dropdownmenu,
                gender
        );
        ArrayAdapter<String> rank_adapter = new ArrayAdapter<>(
                Register.this,R.layout.dropdownmenu,
                rank
        );
        ArrayAdapter<String> province_adapter = new ArrayAdapter<>(
                Register.this,R.layout.dropdownmenu,
                province
        );
        sRgender.setAdapter(gender_adapter);
        sRposition.setAdapter(rank_adapter);
        sRprovince.setAdapter(province_adapter);


    }

    /**
     * Shows the progress UI and hides the login form.
     */
    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    private void showProgress(final boolean show) {
        // On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
        // for very easy animations. If available, use these APIs to fade-in
        // the progress spinner.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);

            mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
            mLoginFormView.animate().setDuration(shortAnimTime).alpha(
                    show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
                }
            });

            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mProgressView.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });

            tvLoad.setVisibility(show ? View.VISIBLE : View.GONE);
            tvLoad.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    tvLoad.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            // The ViewPropertyAnimator APIs are not available, so simply show
            // and hide the relevant UI components.
            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            tvLoad.setVisibility(show ? View.VISIBLE : View.GONE);
            mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
        }
    }

}
