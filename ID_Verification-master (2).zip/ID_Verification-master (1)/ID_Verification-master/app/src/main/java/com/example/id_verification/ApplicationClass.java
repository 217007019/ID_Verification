package com.example.id_verification;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.view.View;
import android.widget.TextView;

import com.backendless.Backendless;

public class ApplicationClass extends Application
{
    public static final String APPLICATION_ID = "0514E5DE-8B8B-7C5B-FF77-19AEC45EF900";
    public static final String API_KEY = "F7E50D2D-1AA6-4372-B824-58EBABADCB27";
    public static final String SERVER_URL = "https://api.backendless.com";

    @Override
    public void onCreate()
    {

        super.onCreate();

        Backendless.setUrl( SERVER_URL );
        Backendless.initApp( getApplicationContext(),
                APPLICATION_ID,
                API_KEY );

    }




}
